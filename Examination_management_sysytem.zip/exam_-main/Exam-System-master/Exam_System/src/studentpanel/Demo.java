package studentpanel;

public class Demo {

/*	public static void main(String[] args) {
		// TODO Auto-generated method stub
Exam ob=new Exam("EID");
//ob.setUndecorated(true);
	}*/

}

